﻿using System;
using System.Threading.Tasks;

namespace 기상청_날씨
{
    class Program
    {
        static async Task Main(string[] args)
        {
            // HttpClientExample example = new HttpClientExample();
            //await example.RunAsync();

            WeatherExample example = new WeatherExample();
            await example.RunAsync();
        }
    }

}
