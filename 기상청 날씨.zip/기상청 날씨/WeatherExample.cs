﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using System.Xml;

namespace 기상청_날씨
{
    public class WeatherExample
    {
        public async Task RunAsync()
        {
            HttpClient client = new HttpClient();
            var response = await client.GetAsync("http://www.kma.go.kr/weather/forecast/mid-term-rss3.jsp?stnId=109");

            // 오류 검사
            if (!response.IsSuccessStatusCode)
            {
                Console.WriteLine($"서버에서 오류를 반환했습니다. 반환 코드={response.StatusCode}");
                return;
            }

            // RSS 데이터 읽기
            string content = await response.Content.ReadAsStringAsync();
            // RSS 안에 정보 읽어 오는 파트
            // Console.WriteLine(content);

            // XML 파싱
            XmlDocument document = new XmlDocument();
            document.LoadXml(content);

            // location인 것들을 다 가져오기
            XmlNodeList nodes = document.DocumentElement.SelectNodes("descendant::location");

            foreach(XmlNode node in nodes)
            {
                // 강원도. 영서 . 춘천을 찾는다.
                var provinceNode = node.SelectSingleNode("province");
                var cityNode = node.SelectSingleNode("city");

                // 오류는 거부
                if (provinceNode == null || cityNode == null) continue;

                // 여기까지 오면. 강원도영서이면서 춘천인 것만 남는다.
                PrintNode(node);

                // 이미 춘천 정보를 다 뽑았으니 더 처리 할 필요가 없다.
                break;

            }

        }

        private void PrintNode(XmlNode sourceNode)
        {
            // data를 모두 뽑아 낸다.
            XmlNodeList nodes = sourceNode.SelectNodes("descendant :: data");

            // 돌면서 하나씩 처리
            foreach (XmlNode node in nodes)
            {
                // tmEf, wf만 뽑아서 보여주면 된다.
                var datanode = node.SelectSingleNode("tmEf");
                var weathernode = node.SelectSingleNode("wf");

                //예외 처리
                if (datanode == null || weathernode == null)continue;

                //출력
                Console.WriteLine($"날짜 : {datanode.InnerText}, 날씨 : {weathernode.InnerText}");

            }
        }
    }


}
